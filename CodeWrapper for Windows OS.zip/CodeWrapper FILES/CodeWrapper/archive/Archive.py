import os
#Welcome to CodeWrapper 
#Use Ctrl+F to find certain text 
print('The most versatile way to edit Python Code.')
os.system('pause')