Some small warnings:

Do not modify any file in this folder except the shortcut. Copy that to your Desktop or anywhere else.
To use the .py versions, you will have to copy them to where the .exe is located.

For any help with software operations, refer to the User Documentation.

Enjoy!
Download more at https://hntechsoftware.github.io