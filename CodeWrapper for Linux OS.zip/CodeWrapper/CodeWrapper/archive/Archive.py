import os
import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import askopenfilename, asksaveasfilename
from tkinter import *
from tkinter.scrolledtext import ScrolledText
import tkinter.ttk as ttk
import win32api
from tkinter import filedialog
import os
import subprocess
import traceback
from tkinter import messagebox
import webbrowser
from tkinter import simpledialog
import re
import ctypes
import keyword
from tkinter import ttk






#Initialize TK window

window = tk.Tk()

#Add icon photo

icon = PhotoImage(file='CodeWrapper/icon.png')
window.iconphoto(False, icon)

#Define column and row widths

window.columnconfigure(0, weight=1)
window.columnconfigure(1, weight=4)
window.rowconfigure(0, weight=2)
window.rowconfigure(1, weight=1)
window.rowconfigure(2, weight=8)
window.rowconfigure(3, weight=2)
window.rowconfigure(4, weight=2)
window.rowconfigure(5, weight=2)
window.rowconfigure(6, weight=2)

logo = tk.PhotoImage(file="CodeWrapper/logo.png")

#Add the banner image
greeting = tk.Label(image=logo, height=100)
window.minsize(800,500)

#initialize variables
current_font_size = 16
dark_mode = False

#define buttons

def open_file():

    """Open a file for editing."""

    filepath = askopenfilename(

        filetypes=[("Text Files", "*.txt"), ("All Files", "*.*"),("Python Files", "*.py")]

    )

    if not filepath:

        return

    usertext.delete("1.0", tk.END)

    with open(filepath, mode="r", encoding="utf-8") as input_file:

        text = input_file.read()

        usertext.insert(tk.END, text)

    window.title(f"WordWrapper by HNTech - {filepath}")

def save_file():

    title = doctitle.get()

    """Save the current file as a new file."""

    filepath = asksaveasfilename(

        defaultextension=".txt",

        filetypes=[("Text Files", "*.txt"), ("All Files", "*.*"),("Python File", "*.py")],

        initialfile = title

    )

    if not filepath:

        return

    with open(filepath, mode="w", encoding="utf-8") as output_file:

        text = usertext.get("1.0", tk.END)

        output_file.write(text)

    window.title(f"CodeWrapper - {filepath}")

def hntechlink():
    webbrowser.open("https://hntechsoftware.github.io")
def cheesecake():
    webbrowser.open("https://youtube.com/c/cheesecakeroblox")

def info():
    win = Toplevel()
    win.title('Info')
    text11 = tk.Label(win, text="CodeWrapper by HNTech",fg="yellow",bg="blue")
    text12 = tk.Label(win, text="Built in 2023 Using Python & Tkinter")
    text13 = tk.Label(win, text="Use the Save as and Open File buttons to navigate.")
    text14 = tk.Label(win, text="Print only works when connected to active printer.")
    text15 = tk.Label(win, text="Execute can be used to debug code, errorbox shows errors.")
    text16 = tk.Label(win, text="If your code has input(), an EOF error occurs. Ignore it.")
    text17 = tk.Label(win, text="For any queries, contact fondgamerfan@gmail.com")
    text18 = tk.Label(win, text="Button & Banner design by @Cheesecake")
    text11.pack()
    text12.pack()
    text13.pack()
    text14.pack()
    text15.pack()
    text16.pack()
    text17.pack()
    text18.pack()
    
    Button(win, text='Download More HNTech Software', command=hntechlink).pack()
    Button(win, text='Check out @Cheesecakes YT', command=cheesecake).pack()

userfont = "Arial"
def font():
    global current_font_size
    font_name = simpledialog.askstring("Font", "Enter Font Name:")
    if font_name:
        font_size = simpledialog.askinteger("Font Size", "Enter Font Size:", initialvalue=current_font_size)
        if font_size:
            current_font_size = font_size
            usertext.config(font=(font_name, font_size))
    



def print_file():
   file= filedialog.askopenfilename(initialdir="/", title="Select any file",filetypes=(("Text files", "*.txt"), ("all files", "*.*"),("Python Files", "*.py")))
   if file:
      os.startfile(file, "print")

def execute():
    text_file = open("CodeWrapper/archive/Archive.py", "w")
    text_file.write("import os")
    text_file.close()
    text_file = open("CodeWrapper/archive/Archive.py", "a")
    text_file.write("\n")
    text_file.write(usertext.get(1.0, END))
    text_file.close()
    text_file = open("CodeWrapper/archive/Archive.py", "a")
    text_file.write("os.system('pause')")
    text_file.close()
    subprocess.run(["python", "CodeWrapper/archive/Archive.py"])
    try:
        result = subprocess.run(["python", "CodeWrapper/archive/Archive.py"], check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        errormessage = e.stderr
        error_message = str(e.returncode)
        messagebox.showerror('Debug',errormessage)

    
def toggle_dark_mode():
    global dark_mode
    if dark_mode:
        window.configure(bg="#F0F0F0")
        C.configure(bg="white")
        usertext.configure(bg="white", fg="black")
        doctitle.configure(bg="white", fg="black")
        dark_mode = False
    else:
        window.configure(bg="black")
        C.configure(bg="black")
        usertext.configure(bg="black", fg="white")
        doctitle.configure(bg="black", fg="white")
        dark_mode = True
        


# Extended the keywords dictionary to include built-in functions.
keywords = {k: 'orange' for k in keyword.kwlist}
keywords['print'] = 'orange'
keywords['input'] = 'orange'
keywords['int'] = 'orange'
keywords['bin'] = 'orange'
keywords['exec'] = 'orange'
keywords['float'] = 'orange'
keywords['True'] = 'orange'
keywords['id'] = 'orange'
keywords['len'] = 'orange'
keywords['range'] = 'orange'

#Define colours
syntax_colors = {
    'comment': 'red',
    'string': 'green',
    'keyword': 'orange',
    'number': 'blue',
}


#define syntax coloring
def tag_keywords(event):
    for keyword, color in keywords.items():
        start = "1.0"
        while True:
            pos = usertext.search(r'\m{}\M'.format(keyword), start, stopindex=tk.END, regexp=True)
            if not pos:
                break
            end = f"{pos}+{len(keyword)}c"
            usertext.tag_add("keyword", pos, end)
            start = end
        usertext.tag_config("keyword", foreground=syntax_colors['keyword'])

def tag_comments(event):
    usertext.tag_configure("comment", foreground=syntax_colors['comment'])
    start = "1.0"
    while True:
        start = usertext.search("#", start, stopindex=tk.END)
        if not start:
            break
        end = usertext.search("\n", start, stopindex=tk.END)
        if not end:
            end = tk.END
        usertext.tag_add("comment", start, end)
        start = end

def tag_strings(event):
    usertext.tag_configure("string", foreground=syntax_colors['string'])
    start = "1.0"
    while True:
        start = usertext.search(r'[rR]?[bB]?"[^"\\]*(\\.[^"\\]*)*"', start, stopindex=tk.END, regexp=True)
        if not start:
            break
        end = usertext.search('"', start+"+1c", stopindex=tk.END, regexp=True)
        if not end:
            end = tk.END
        usertext.tag_add("string", start, end+"+1c")
        start = end

    start = "1.0"
    while True:
        start = usertext.search(r"[rR]?[bB]?'[^'\\]*(\\.[^'\\]*)*'", start, stopindex=tk.END, regexp=True)
        if not start:
            break
        end = usertext.search("'", start+"+1c", stopindex=tk.END, regexp=True)
        if not end:
            end = tk.END
        usertext.tag_add("string", start, end+"+1c")
        start = end

def tag_numbers(event):
    usertext.tag_configure("number", foreground=syntax_colors['number'])
    text_string = usertext.get("1.0", tk.END)
    for match in re.finditer(r"\b\d+\b", text_string):
        start, end = match.span()
        usertext.tag_add("number", f"1.0 + {start} chars", f"1.0 + {end} chars")


def tag_all(event=None):
    tag_keywords(event)
    tag_numbers(event)  # tag numbers
    tag_comments(event)  # comments should be tagged middle
    tag_strings(event)
    



#Define text widgets

doctitle = tk.Entry(width=100)

window.title('CodeWrapper by HNTech')

C = tk.Canvas(window, bg="white", height=800, width=200)
C.grid(column=0,rowspan=3)

greeting.grid(row=0,column=1)
usertext = tk.Text(width=90)
Font = ("Arial", 16)
usertext.configure(font=Font)

doctitle.grid(column=1,row=1)

doctitle.insert(0,"Untitled Document")
usertext.grid(column=1,row=2,rowspan=6)

usertext.bind('<Any-KeyRelease>', tag_all)



chars_per_line = 90


#scrollbar
sb = tk.Scrollbar(
    window,
    orient=VERTICAL,
    activebackground="blue",
    troughcolor="blue",
    )

sb.grid(row=2, column=2, sticky="NS", rowspan=6)

usertext.config(yscrollcommand=sb.set)
sb.config(command=usertext.yview)


#define the buttons themself

openafile= tk.PhotoImage(file='CodeWrapper/openew.png')


openafilelabel= Label(image=openafile)

openfilebutton= Button(window, image=openafile,command= open_file,
borderwidth=0,width=170,height=50)



savebutton= tk.PhotoImage(file='CodeWrapper/savefile.png')


saveafilelabel= Label(image=savebutton)

savefilebutton= Button(window, image=savebutton,command= save_file,
borderwidth=0,width=170,height=50)



printbutton= tk.PhotoImage(file='CodeWrapper/print.png')


printfilelabel= Label(image=printbutton)

printfilebutton= Button(window, image=printbutton,command= print_file,
borderwidth=0,width=170,height=50)




executebutton= tk.PhotoImage(file='CodeWrapper/execute.png')


executefilelabel= Label(image=executebutton)

executefilebutton= Button(window, image=executebutton,command= execute,
borderwidth=0,width=170,height=50)

infobutton= tk.PhotoImage(file='CodeWrapper/info.png')


infofilelabel= Label(image=infobutton)

infofilebutton= Button(window, image=infobutton,command= info,
borderwidth=0,width=130,height=50)

fontbutton= tk.PhotoImage(file='CodeWrapper/font.png')


fontfilelabel= Label(image=fontbutton)

fontfilebutton= Button(window, image=fontbutton,command= font,
borderwidth=0,width=130,height=50)


colourbutton= tk.PhotoImage(file='CodeWrapper/togglecolour.png')


colourfilelabel= Label(image=colourbutton)

colourfilebutton= Button(window, image=colourbutton,command= toggle_dark_mode,
borderwidth=0,width=110,height=50)

#add buttons

openfilebutton.place(x=10,y=10)
savefilebutton.place(x=10,y=100)
printfilebutton.place(x=10,y=190)
executefilebutton.place(x=10,y=280)
fontfilebutton.place(x=10,y=370)
colourfilebutton.place(x=10,y=460)
infofilebutton.place(x=10,y=550)





#run the loop
window.mainloop()

os.system('pause')